﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ecz30April_15zadanie
{
    class Program
    {
        static void Main()
        {
            int[,] mas =
            {
                {1, 2, 1, 4, -8},
                {5, -1, 2, 2, 1},
                {1, 2, -3, 4, 5},
                {5, 7, 4, 2, -5},
                {5, 7, 5, 2, 0}
            };

            int index = GetSameRowColumn(mas);
            Console.WriteLine("Индекс: " + index);

            int totalValue = 0;
            for (int i = 0; i < mas.GetLength(0); i++)
            {
                int sum = 0;
                bool hasNegative = false;
                for (int j = 0; j < mas.GetLength(1); j++)
                {
                    sum += mas[i, j];
                    hasNegative |= mas[i, j] < 0;
                }
                if (hasNegative)
                    totalValue += sum;
            }

            Console.WriteLine("Сумма всех элементов: " + totalValue);
            Console.ReadKey();
        }

        private static int GetSameRowColumn(int[,] a)
        {
            if (a.GetLength(0) != a.GetLength(1))
                return -1;
            int n = a.GetLength(0);
            for (int i = 0; i < n; i++)
            {
                int j = 0;
                for (; j < n && a[i, j] == a[j, i]; j++)
                { }
                if (j == n)
                    return i;
            }
            return -1;
        }
    }
}
